"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import Image from "next/image";
import SearchModal from "@/app/common-components/SearchModal";

interface MobileSubItem {
  name: string;
  slug: string;
}

interface MobileMenuGroup {
  label: string;
  href: string;
  items: MobileSubItem[];
}

/* =========================
   ABOUT
========================= */
const aboutItems: MobileSubItem[] = [

  { name: "Company", slug: "about-us" },
  { name: "Media", slug: "media" },
    { name: "Blog", slug: "blogs" },
];

/* =========================
   SERVICES
========================= */
const servicesItems: MobileSubItem[] = [
  
  { name: "B2B Branding", slug: "b2b-branding" },
  {
    name: "Corporate Photography & Videography",
    slug: "corporate-photography-videography-services",
  },
  { name: "Export & International SEO", slug: "export-international-seo" },
  { name: "Industrial Website Design", slug: "industrial-website-desgin" },
  { name: "Local & Google Business SEO", slug: "local-google-business-seo" },
  { name: "Product Catalogue Websites", slug: "product-catalogue-websites" },
  { name: "Website Redesign For Industry", slug: "website-redesign-for-industry" },
  { name: "All Services", slug: "all-services" },
];

/* =========================
   INDUSTRIES
========================= */
const industriesItems: MobileSubItem[] = [
  
  { name: "Auto Parts & Engineering", slug: "auto-parts-engineering" },
    {
    name: "Chemical & Pharmaceutical Manufacturers",
    slug: "chemical-pharmaceutical-manufacturers",
  },
  { name: "Cycle & Sports Equipment", slug: "cycle-sports-equipment" },
   { name: "Fasteners & Hardware", slug: "fasteners-hardware" },
  { name: "Hosiery & Textile Exporters", slug: "hosiery-textile-exporters" },
  { name: "Logistics & Industrial", slug: "logistics-industrial" },
  { name: "Machine Tools & Precision", slug: "machine-tools-precision" },
  { name: "Packaging & Plastics", slug: "packaging-plastics" },
  { name: "Steel & Metal Fabrication", slug: "steel-metal-fabrication" },
  
  { name: "All Industries", slug: "all-industries-page" },
];

/* Desktop jaisa order: About, Services, Industries, Work, Careers, Contact, Search */
const menuGroups: MobileMenuGroup[] = [
  { label: "ABOUT", href: "#", items: aboutItems },
  { label: "SERVICES", href: "#", items: servicesItems },
  { label: "INDUSTRIES", href: "#", items: industriesItems },
  { label: "WORK", href: "/work", items: [] },
  { label: "CAREERS", href: "/careers", items: [] },
  { label: "CONTACT", href: "/contact-us", items: [] },
  { label: "SEARCH", href: "/search", items: [] },
];

export default function MobileHeader() {
  const pathname = usePathname();
  const isHome = pathname === "/";

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [openGroup, setOpenGroup] = useState<string | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);

  useEffect(() => {
    setDrawerOpen(false);
    setOpenGroup(null);
  }, [pathname]);

  // Sirf drawer khula ho tab scroll lock. (Drawer band hote hi search modal
  // khulta hai, to yahan overflow "" set nahi karna warna modal ka lock hat jata hai)
  useEffect(() => {
    if (!drawerOpen) return;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, [drawerOpen]);

  const toggleGroup = (label: string) => {
    setOpenGroup((prev) => (prev === label ? null : label));
  };

  return (
    <>
      <div
        className={`mobileHeader ${
          isHome ? "mobileHeaderHome" : "mobileHeaderSolid"
        }`}
      >
        <div className="mobileBar">
          {/* Hamburger */}
          <button
            type="button"
            aria-label="Open menu"
            className="mobileHamburger"
            onClick={() => setDrawerOpen(true)}
          >
            <span />
            <span />
            <span />
          </button>

          {/* Right icons */}
          <div className="mobileIcons">
            {!isHome && (
              <Link href="/">
                <Image
                  src="/homelogo.png"
                  alt="logo"
                  width={0}
                  height={0}
                  sizes="70vw"
                  className="imagee-stlak"
                  priority
                />
              </Link>
            )}
          </div>
        </div>

        {/* Overlay */}
        <div
          className={`mobileOverlay ${drawerOpen ? "mobileOverlayOpen" : ""}`}
          onClick={() => setDrawerOpen(false)}
        />

        {/* Drawer */}
        <div className={`mobileDrawer ${drawerOpen ? "mobileDrawerOpen" : ""}`}>
          <div className="mobileDrawerHeader">
            <button
              type="button"
              aria-label="Close menu"
              className="mobileClose"
              onClick={() => setDrawerOpen(false)}
            >
              <svg
                viewBox="0 0 24 24"
                width="22"
                height="22"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
              >
                <path d="M6 6l12 12M18 6L6 18" />
              </svg>
            </button>
          </div>

          <nav className="mobileNavList">
            {menuGroups.map((group) => (
              <div key={group.label} className="mobileNavItem">
                {group.items.length > 0 ? (
                  <>
                    <button
                      type="button"
                      className="mobileNavLink mobileAccordionToggle"
                      onClick={() => toggleGroup(group.label)}
                    >
                      {group.label}
                      <span
                        className={`mobileAccordionIcon ${
                          openGroup === group.label
                            ? "mobileAccordionIconOpen"
                            : ""
                        }`}
                      >
                        <svg
                          viewBox="0 0 24 24"
                          width="16"
                          height="16"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M6 9l6 6 6-6" />
                        </svg>
                      </span>
                    </button>

                    <div
                      className={`mobileSubList ${
                        openGroup === group.label ? "mobileSubListOpen" : ""
                      }`}
                    >
                      {group.items.map((item) => (
                        <Link
                          key={item.slug}
                          href={`/${item.slug}`}
                          className="mobileSubLink"
                          onClick={() => setDrawerOpen(false)}
                        >
                          {item.name}
                        </Link>
                      ))}
                    </div>
                  </>
                ) : group.label === "SEARCH" ? (
                  <button
                    type="button"
                    className="mobileNavLink"
                    onClick={() => {
                      setDrawerOpen(false);
                      setSearchOpen(true);
                    }}
                  >
                    {group.label}
                  </button>
                ) : (
                  <Link
                    href={group.href}
                    className="mobileNavLink"
                    onClick={() => setDrawerOpen(false)}
                  >
                    {group.label}
                  </Link>
                )}
              </div>
            ))}
          </nav>
        </div>
      </div>

      <SearchModal open={searchOpen} onClose={() => setSearchOpen(false)} />
    </>
  );         
}      