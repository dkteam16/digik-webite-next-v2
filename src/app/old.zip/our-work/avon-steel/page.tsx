  // import Allinone from "@/app/common-components/ourwork-all"
  // export default function loacl() {
  //   return (
  
  //     <div className="cycle-sport  all-indus-pagemian">       
  //         <Allinone
  //             label={[
  //                 { label: "" }
  //             ]}
  //             tag="Cycle Parts & Sports Equipment Manufacturers"
  //             titlePrefix="The Ludhiana Cycle Cluster Deserves a World-Class Digital Presence"
  //             titleHighlight="  "
  //               titlePrefixtwo=" " 
  //             description="Ludhiana manufactures 70% of India's cycles and cycle parts — yet most manufacturers in the cluster are invisible online to the global buyers who want to source from them. We fix that."
  //             intro={[
  //                 { value: "" , label:""  }
  //             ]}
  //             backgroundImage="/about/startback.webp"
  //             rightImage="/about/iso.png"
  //             stats={[
  //                 { value: "70%", label: "India's cycles made in Ludhiana" },
  //                 { value: "0%", label: "Cluster online visibility (typical)" },
  //                 { value: "5x", label: "Export inquiry growth we target" }, 
  //             ]}
  //         />  
          
    
  //     </div>
  //   );
  // }
