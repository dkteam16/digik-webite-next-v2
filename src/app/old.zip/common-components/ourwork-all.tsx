// import Link from "next/link";
// import Image from "next/image";

// type Stat = {
//   value: string;
//   label: string;
// };
// type label = {
//   value: string; 
// }

// type intro = {
//   value: string;
//   label: string;
// };

// type ButtonItem = {
//   text: string;
//   link: string;
// };

// type AllinoneProps = {
//   tag: string;
//   titlePrefix: string;
//   titleHighlight: string;
//   titlePrefixtwo: string;
//   description: string;
//   buttons: ButtonItem[];
//   backgroundImage: string;
//   rightImage: string;
//   stats: Stat[];
// };

// export default function Allinone({
//   tag,
//   titlePrefix,
//   titleHighlight,
//   titlePrefixtwo,
//   description,
//   intro,  
//   label,
//   rightImage,
//   stats,
// }: AllinoneProps) {
//   return (
//     <div className="allinone bg-white">
//       <div className="allinone-iner">
//         <div className="allinone-iner-left relative">
//            <ul className="left-all-bottom-in">
//                 {stats.map((label, index) => (
//                     <li className="left-all-bottom " key={index}>
//                         <p>{label.label}</p>
//                     </li>
//                 ))}
//            </ul>
//            <p className="text-[#F4A31D]">{tag}</p>
//             <h1>
//                 <span dangerouslySetInnerHTML={{ __html: titlePrefix }} />{" "}
//                 <span className="text-[#F4A31D]" dangerouslySetInnerHTML={{ __html: titleHighlight }}/>
//                     {" "}
//                 <span dangerouslySetInnerHTML={{ __html: titlePrefixtwo }} />
//             </h1>
//            <p className="text-[#333333] all-one-border">{description}</p>
//            <ul  className="left-all-bottom ">
//                 {stats.map((intro, index) => (
//                     <li key={index}>
//                     <h4>{intro.value}</h4>
//                     <p>{intro.label}</p>
//                     </li>
//                 ))}
//            </ul>
//         </div> 
//         <div className="allinone-iner-right relative">
//           <Image
//             src={rightImage}
//             alt="logo"
//             width={0}
//             height={0}
//             sizes="100vw"
//             className="allinoneimage"
//             priority
//           />
//           {stats.map((stat, index) => (
//             <div className="allinone-iner-right-in" key={index}>
//               <h4>{stat.value}</h4>
//               <p>{stat.label}</p>
//             </div>
//           ))}
//         </div>
//       </div>
//     </div>  
//   ); 
// }